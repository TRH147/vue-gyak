<template>
  <div class="container">
    <div class="text-center mt-5">
      <h1>Kezdőlap</h1>
      <p>Ez a webhely néhány motorról szolgáltat információkat.<br>
         A „Motorok” menüpontban a kiválasztott motorról a „Részletek” gombra történő kattintás után további információkhoz juthat.</p>
    </div>
  </div>
</template>
