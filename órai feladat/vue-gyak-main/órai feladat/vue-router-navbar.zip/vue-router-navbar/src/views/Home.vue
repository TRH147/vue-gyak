<template>
  <div>
    <h1>Kezdőlap</h1>
    <p>Ez az alkalmazás kezdőoldala.</p>
  </div>
</template>

<script>
export default {
  name: 'Home',
}
</script>
